<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

//Banner
Route::get('banner', 'App\Http\Controllers\Api\ApiController@banner');

//Client
Route::get('client', 'App\Http\Controllers\Api\ApiController@client');

//Certificate
Route::get('certificate', 'App\Http\Controllers\Api\ApiController@certificate');

//Gallery
Route::get('gallery', 'App\Http\Controllers\Api\ApiController@gallery');

//CMS
Route::get('cms', 'App\Http\Controllers\Api\ApiController@cms');
Route::get('cms/{slug}', 'App\Http\Controllers\Api\ApiController@cms_detail');

//Industry
Route::get('industry', 'App\Http\Controllers\Api\ApiController@industry');

//Product
Route::get('product', 'App\Http\Controllers\Api\ApiController@product');
Route::get('product/{slug}', 'App\Http\Controllers\Api\ApiController@product_detail');

//Conatct
Route::post('contact', 'App\Http\Controllers\Api\ApiController@contact');
 	
<?php $__env->startSection('main_container'); ?>
<!-- begin app-main -->
<div class="app-main" id="main">
   <!-- begin container-fluid -->
   <div class="container-fluid">
      <!-- begin row -->
      <div class="row">
         <div class="col-md-12 m-b-30">
            <!-- begin page title -->
            <div class="d-block d-sm-flex flex-nowrap align-items-center">
               <div class="page-title mb-2 mb-sm-0">
                  <h1>Product</h1>
               </div>
               <div class="ml-auto d-flex align-items-center">
                  <a class="btn btn-dark text-white" href="<?php echo e(route('product')); ?>">Manage Product</a>
               </div>
            </div>
            <!-- end page title -->
         </div>
      </div>
      <!-- end row -->
      <!--mail-Compose-contant-start-->
      <?php
      function categoryTree($parent_id = 0, $sub_mark = ''){
      
          $query =  DB::table('category')->where('parent_id','=', $parent_id)->get();
         
          if(count($query) > 0){
              foreach($query as $value){
                  echo '<option value="'.$value->cat_id.'">'.$sub_mark.$value->cat_name.'</option>';
                  categoryTree($value->cat_id, $sub_mark.'---');
              }
          }
      }
      ?>
      <div class="row account-contant">
         <div class="col-12">
            <div class="card card-statistics">
               <div class="card-body p-0">
                  <!-- <div class="row no-gutters"> -->
                  <div class="page-account-form">
                     <div class="form-titel border-bottom p-3">
                        <h5 class="mb-0 py-2">Add Product</h5>
                     </div>
                     <div class="p-3">
                        <form role="form" method="POST" id="productForm" enctype="multipart/form-data" action="<?php echo e(route('createproduct')); ?>">
                           <?php echo csrf_field(); ?>
                          
                           <div class="row">
                              
                              <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                 <div class="form-group">
                                    <label>Product Name<span style="color:#ff0000">*</span></label>
                                       <input class="form-control" value="<?php echo e(old('title')); ?>" name="title" placeholder="Enter Product Name" type="text" required>
                                       <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       <p class="text-danger"><small><?php echo e($message); ?></small></p>
                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                              </div>
                              <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="form-group">
                                      <label>Sub Title</label>
                                      <input class="form-control" value="<?php echo e(old('subtitle')); ?>" name="subtitle" placeholder="Enter Sub Title" type="text">
                                </div>
                             </div>
                           
                           </div>

                           <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                    <div class="form-group">
                                    <label>Category</label>
                                    <select name="category_id" class="form-control  selectpicker "  data-show-subtext="true" data-live-search="true">
                                        <option value="">Please Select</option>
                                        <?php
                                            echo categoryTree();
                                        ?>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                    <div class="form-group">
                                        <label>Application</label>
                                        <select name="application_id[]" class="form-control  selectpicker " multiple data-show-subtext="true" data-live-search="true">
                                            <option value="">Please Select</option>
                                            <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($ap->id); ?>"><?php echo e($ap->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                    <div class="form-group">
                                            <label>Alt Tag</label>
                                            <input class="form-control" value="<?php echo e(old('atl_tag')); ?>" name="atl_tag" placeholder="Enter Alt Tag" type="text">
                                    </div>
                                </div>
                              
                                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                    <div class="form-group">
                                        <label>Product Order</label>
                                        <input class="form-control" name="orderby"  placeholder="Enter Product Order" value="<?php echo e(old('orderby')); ?>" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                    <div class="form-group">
                                        <label>Image</label>
                                        <input class="form-control" name="image" type="file">
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><small><?php echo e($message); ?></small></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                              
                            </div>
                              
                           <div class="row">

                              <div class="col-lg-12 col-md-12 col-sm-12 col-12">
   
                                 <div class="form-group">

                                    <label>Rubric Field</label>

                                    <div class="quill-editor">

                                       <div id="prod_rubric" class="prod_rubric"><?php echo  old('rubric') ?></div>
      
                                    </div>
      
                                    <input type="hidden" class="form-control" id="prod_rub" name="rubric" >

                                 
                                 </div>

                              </div>

                           </div>

                            <div class="row">

                              <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                 <div class="form-group">

                                    <label>Description</label>

                                    <div class="quill-editor">

                                        <div id="prod_desc" class="prod_desc"><?php echo  old('desc') ?></div>
       
                                    </div>
    
                                    <input type="hidden" class="form-control" id="prod_des" name="desc" >

                                 </div>

                              </div>

                           </div> 

                           <div class="row">

                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                               <div class="form-group">

                                  <label>Properties</label>

                                  <div class="quill-editor">

                                      <div id="prod_prop" class="prod_prop"><?php echo  old('property') ?></div>
     
                                  </div>
  
                                  <input type="hidden" class="form-control" id="prod_pro" name="property" >

                               </div>

                            </div>

                         </div>

                         <div class="row">

                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                               <div class="form-group">

                                  <label>Solubility</label>

                                  <div class="quill-editor">

                                      <div id="prod_sol" class="prod_sol"><?php echo  old('solubility') ?></div>
     
                                  </div>
  
                                  <input type="hidden" class="form-control" id="prod_sl" name="solubility" >

                               </div>

                            </div>

                         </div>

                         <div class="row">

                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                               <div class="form-group">

                                  <label>Specification</label>

                                  <div class="quill-editor">

                                      <div id="prod_spec" class="prod_spec"><?php echo  old('specification') ?></div>
     
                                  </div>
  
                                  <input type="hidden" class="form-control" id="prod_spe" name="specification" >

                               </div>

                            </div>

                         </div>
                           

              
                           <h2 class="p-1  text-black">SEO Filed</h2>
                           <div class="row">
                              <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                 <div class="form-group">
                                    <label>Meta Title</label>
                                    <input class="form-control" value="<?php echo e(old('meta_title')); ?>"  placeholder="Enter Meta Title" name="meta_title" type="text">                       
                                 </div>
                              </div>
                              <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                 <div class="form-group">
                                    <label>Meta keyword</label>
                                    <input class="form-control" value="<?php echo e(old('meta_keyword')); ?>" name="meta_keyword" placeholder="Enter Keyword" type="text">
                                 </div>
                              </div>
                           </div>

                           <div class="row">
                              <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                 <div class="form-group">
                                    <label>Meta Description</label> 
                                    <textarea class="form-control"  name="meta_desc" cols="50" rows="15" style="width:100%;px; height:300px;" mce_editable="true"></textarea>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                 <div class="text-left">
                                    <button type="submit" id="submit" class="btn btn-dark text-white my-4">Add</button>
                                    <a href="<?php echo e(route('product')); ?>"  class="btn btn-danger my-4">Cancel</a>
                                 </div>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
                  <!-- </div> -->
               </div>
            </div>
         </div>
      </div>
      <!--mail-Compose-contant-end-->
   </div>
   <!-- end container-fluid -->
</div>
<!-- end app-main -->
</div>
<!-- end app-container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layout.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yogeshwar\resources\views/Admin/product/add.blade.php ENDPATH**/ ?>
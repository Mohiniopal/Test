 	

<?php $__env->startSection('main_container'); ?>

<!-- begin app-main -->

<div class="app-main" id="main">

   <!-- begin container-fluid -->

   <div class="container-fluid">

      <!-- begin row -->

      <div class="row">

         <div class="col-md-12 m-b-30">

            <!-- begin page title -->

            <div class="d-block d-sm-flex flex-nowrap align-items-center">

               <div class="page-title mb-2 mb-sm-0">

                  <h1>Banner</h1>

               </div>

               <div class="ml-auto d-flex align-items-center">

                  <a class="btn btn-dark text-white" href="<?php echo e(route('banner')); ?>">Manage Banner</a>

               </div>

            </div>

            <!-- end page title -->

         </div>

      </div>

      <!-- end row -->

      <!--mail-Compose-contant-start-->

      <div class="row account-contant">

         <div class="col-12">

            <div class="card card-statistics">

               <div class="card-body p-0">

                  <!-- <div class="row no-gutters"> -->

                  <div class="page-account-form">

                     <div class="form-titel border-bottom p-3">

                        <h5 class="mb-0 py-2">Add Banner</h5>

                     </div>

                     <div class="p-3">

                        <form role="form" method="POST" id="Bannerform" enctype="multipart/form-data" action="<?php echo e(route('createBanner')); ?>">

                           <?php echo csrf_field(); ?>

                           <div class="row">

                            <div class="col-lg-6 col-md-6 col-sm-12 col-12">

                                <div class="form-group">

                                <label>Banner Name<span style="color:#ff0000">*</span></label>

                                <input class="form-control" value="<?php echo e(old('banner_name')); ?>" name="banner_name" placeholder="Enter Banner Name" type="text" required>

                                <?php $__errorArgs = ['banner_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <p class="text-danger"><small><?php echo e($message); ?></small></p>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-12 col-12">

                              <div class="form-group">

                              <label>Alt Tag</label>

                              <input class="form-control" value="<?php echo e(old('alt_tag')); ?>" name="alt_tag" placeholder="Enter Alt Tag" type="text">

                              </div>

                          </div>

                        </div>

                        <div class="row">

                           <div class="col-lg-6 col-md-6 col-sm-12 col-12">

                              <div class="form-group">

                              <label>Order By</label>

                              <input class="form-control" value="<?php echo e(old('orderby')); ?>" name="orderby" placeholder="Enter Order By" min="0" value="0" type="number">

                              </div>

                          </div>

                            <div class="col-lg-6 col-md-6 col-sm-12 col-12">

                                <div class="form-group">

                                <label>Banner Link</label>

                                <input class="form-control" value="<?php echo e(old('banner_link')); ?>" name="banner_link" placeholder="Enter Banner link" type="text">

                                </div>

                            </div>

                        </div>

                        <div class="row">

                           <div class="col-lg-6 col-md-6 col-sm-12 col-12">

                              <div class="form-group">

                              <label>Desktop Image</label>

                              <input class="form-control"   name="desktop_image" type="file">

                              <?php $__errorArgs = ['desktop_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                              <p class="text-danger"><small><?php echo e($message); ?></small></p>

                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                              </div>

                          </div>

                            <div class="col-lg-6 col-md-6 col-sm-12 col-12">

                                <div class="form-group">

                                <label>Mobile Image</label>

                                <input class="form-control"   name="mobile_image" type="file">

                                <?php $__errorArgs = ['mobile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <p class="text-danger"><small><?php echo e($message); ?></small></p>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>

                        </div>

                         

                        <div class="row">

                           <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                              <div class="form-group">

                              <label>Banner Heading</label>

                              <div class="quill-editor">

                                 <div id="banner_desc" class="banner_desc"><?php echo e(old('banner_desc')); ?></div>

                              </div>

                              <input type="hidden" class="form-control" id="banner_des" name="banner_desc" >

                             

                              </div>

                          </div>

                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                <div class="form-group">

                                <label>Banner Sub Heading</label>

                                 <div class="quill-editor">

                                       <div id="banner_sub_heading" class="banner_sub_heading"><?php echo e(old('banner_sub_heading')); ?></div>

                                 </div>

                                 <input type="hidden" class="form-control" id="banner_sub_head"  name="banner_sub_heading" >

                              

                                </div>

                            </div>

                        </div>

                           <div class="row">

                              <div class="col-lg-6 col-md-6 col-sm-12 col-12">

                                 <div class="text-left">

                                    <button type="submit" id="submit" class="btn btn-dark text-white my-4">Add</button>

                                    <a href="<?php echo e(route('banner')); ?>"  class="btn btn-danger my-4">Cancel</a>

                                 </div>

                              </div>

                           </div>

                        </form>

                     </div>

                  </div>

                  <!-- </div> -->

               </div>

            </div>

         </div>

      </div>

      <!--mail-Compose-contant-end-->

   </div>

   <!-- end container-fluid -->

</div>

<!-- end app-main -->

</div>

<!-- end app-container -->



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Admin.Layout.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yogeshwar\resources\views/Admin/banner/add.blade.php ENDPATH**/ ?>
<html>



        <head>



        <title>Enquiry For</title>



        </head>



        <body>

                        <table cellspacing='0px' style='width: auto; color: #333; border: 3px double #2957a4; padding: 20px;' align='center'>

                          <tr align='center'>

                            <td colspan='2' style='border:none !important; padding-bottom:20px;padding-top:20px;'><img src="{{url('Admin/assets/img/LOGO_1.png')}}" alt='aelocks' /></td>

                          </tr>



                          <tr>

                          <td align='left' bgColor='#f2f2f2' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;width:200px'><strong>Name:</strong></td>

                          <td bgColor='#f2f2f2' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;width:250px'><?php echo $full_name ?></td>

                          </tr>

                          <tr>

                          <td align='left' bgColor='#fff' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;width:200px'><strong>Email ID:</strong></td>

                          <td bgColor='#fff' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;width:250px'><?php echo $email ?></td>

                          </tr>

                          <tr>

                          <td align='left' bgColor='#f2f2f2' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;width:200px'><strong>Mobile No:</strong></td>

                          <td bgColor='#f2f2f2' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;'><?php echo $phone_number ?></td>

                          </tr>

                          <tr>

                          <td align='left' bgColor='#fff' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;width:200px'><strong>City:</strong></td>

                          <td bgColor='#fff' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;width:250px'> <?php echo $city ?></td>

                          </tr>

                          <tr>

                          <td align='left' bgColor='#f2f2f2' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;width:200px'><strong>Country:</strong></td>

                          <td bgColor='#f2f2f2' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;'> <?php echo $country ?></td>

                          </tr>

                         

                          <tr>

                          <td align='left' bgColor='#f2f2f2' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;width:200px'><strong>Qualification:</strong></td>

                          <td bgColor='#f2f2f2' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;'><?php echo $qualification ?></td>

                          </tr>

                          <tr>

                          <td align='left' bgColor='#fff' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;width:200px'><strong>Experience:</strong></td>

                          <td bgColor='#fff' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;width:250px'><?php echo $job_experience ?></td>

                          </tr>

                          <tr>

                          <td align='left' bgColor='#f2f2f2' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;width:200px'><strong>Expected Salary:</strong></td>

                          <td bgColor='#f2f2f2' style='border:1px solid #ccc;padding:10px; font-family: Open Sans, sans-serif;font-size:16px;'><?php echo $salary ?></td>

                          </tr>

                         </table>



             

                   





        </body>



        </html>
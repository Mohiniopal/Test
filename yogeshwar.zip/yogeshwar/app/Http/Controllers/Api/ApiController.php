<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Banner;
use App\Models\Client;
use App\Models\certificate;
use App\Models\Gallery;
use App\Models\Page;
use App\Models\Category;
use App\Models\Product;
use App\Models\ApplicationProduct;
use App\Models\ProductImage;
use App\Models\Contact;

class ApiController extends Controller
{
    public function banner()
    {
        $data = Banner::select(['banner_id','banner_name','mobile_image','banner_link','orderby','desktop_image','banner_sub_heading','banner_desc','alt_tag'])
        ->orderBy('orderby', 'ASC')->get(); 
        return response()->json([
            'code' => 200,
            'success' => True,
            'banner' => $data,
        ]);
    }

    public function client()
    {
        $data = Client::orderBy('orderby', 'ASC')->get(); 
        return response()->json([
            'code' => 200,
            'success' => True,
            'client' => $data,
        ]);
    }

    public function certificate()
    {
        $data = certificate::orderBy('orderby', 'ASC')->get(); 
        return response()->json([
            'code' => 200,
            'success' => True,
            'certificate' => $data,
        ]);
    }

    public function gallery()
    {
        $data = Gallery::orderBy('orderby', 'ASC')->get();
        return response()->json([
            'code' => 200,
            'success' => True,
            'gallery' => $data,
        ]);
    }

    public function cms()
    {
        $data = Page::get(['pg_id','pg_name','slug','meta_title']);
        return response()->json([
            'code' => 200,
            'success' => True,
            'cms' => $data,
        ]);
    }

    public function cms_detail($slug)
    {
        $data = Page::where('slug',$slug)->first();
        return response()->json([
            'code' => 200,
            'success' => True,
            'cms' => $data,
        ]);
    }

    public function industry()
    {
        $data = Category::orderBy('cat_order', 'ASC')->get(['cat_id','cat_name','slug','meta_title','cat_img','alt_tag','cat_order']); 
        return response()->json([
            'code' => 200,
            'success' => True,
            'industry' => $data,
        ]);
    }

    public function product()
    {
        $data = Product::orderBy('orderby', 'ASC')->get(['id','title','slug','image','alt_tag','meta_title']);
        return response()->json([
            'code' => 200,
            'success' => True,
            'product' => $data,
        ]);
    }

    public function product_detail($slug)
    {
        $data = Product::where('slug',$slug)->first();

        $product_id = $data->id;
        $application = ApplicationProduct::leftjoin('applications','applications.id','=','application_product.application_id')
                                         ->where('product_id',$product_id)
                                         ->get(['applications.name','applications.slug']);

        $data->applications = $application;

        $images = ProductImage::where('product_id',$product_id)->orderBy('orderby', 'ASC')->get(['image','alt_tag','orderby']);

        $data->productImage = $images;

        return response()->json([
            'code' => 200,
            'success' => True,
            'product' => $data,
        ]); 
    }

    public function contact(Request $request)
    {
       
        $validatedData = $request->validate([
            'full_name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone_number' => 'nullable|string|max:20',
         
        ]);

       
        $data = $validatedData;

       
        Mail::send('contact.contactmail', $data, function ($message) use ($data) {
            $message->to('opal911@opal.in')->subject('New Contact Form submitted from Website');
            $message->from('opal966@opal.in', 'Yogeshwar Polymers');
        });

       
        Contact::create([
            'full_name' => $data['full_name'],
            'email' => $data['email'],
            'phone_number' => $data['phone_number'] ?? '',
            'address' => $data['address'] ?? '',
            'message' => $data['message'],
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Your form has been submitted successfully',
        ]);
    }

}
